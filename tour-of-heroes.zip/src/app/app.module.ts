import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HeroesComponent } from './_components/heroes/heroes.component';
import { HeroDetailComponent } from './_components/hero-detail/hero-detail.component';
import { SeasonComponent } from './_components/season/season.component';
import { DashboardComponent } from './_components/dashboard/dashboard.component';
import { MessagesComponent } from './_components/messages/messages.component';
import { VillainsComponent } from './_components/villains/villains.component';
import { FormComponent } from './_components/form/form.component';

@NgModule({
  declarations: [
    AppComponent,
    HeroesComponent,
    HeroDetailComponent,
    SeasonComponent,
    DashboardComponent,
    MessagesComponent,
    VillainsComponent,
    FormComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
