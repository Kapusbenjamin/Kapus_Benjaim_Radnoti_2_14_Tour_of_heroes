import { Component } from '@angular/core';
import { Hero } from './_models/hero';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.less']
})
export class AppComponent {
  //data binding
  appType: string = "Angular"

  hero: Hero = {
    id: 1,
    name: "Batman",
    // age: 32
    superPower: "Fly",
    died: "false"
  }

}
