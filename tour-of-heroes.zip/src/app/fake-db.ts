import { Hero } from "./_models/hero";
import { Season } from "./_models/season";
import { Villain } from "./_models/villain";

export const HEROES: Hero[] = [
  { id: 1, name: 'Batman', superPower: "Telekinesis", died: "true" },
  { id: 2, name: 'Bombasto', superPower: "Under Water Control", died: "false"  },
  { id: 3, name: 'Celeritas', superPower: "Super Strength", died: "false"  },
  { id: 4, name: 'Magneta', superPower: "Super Speed", died: "true"  },
  { id: 5, name: 'RubberMan', superPower: "Healing", died: "false"  },
  { id: 6, name: 'Dynama', superPower: "Shapeshifting", died: "false"  },
  { id: 7, name: 'Dr. IQ', superPower: "Invisibility", died: "true"  },
  { id: 8, name: 'Magma', superPower: "Flight", died: "true"  },
  { id: 9, name: 'Tornado', superPower: "Telekinesis", died: "false"  }
];

export const SEASONS: Season[] = [
  {id: 1, name: 'Spring'},
  {id: 2, name: 'Summer'},
  {id: 3, name: 'Fall'},
  {id: 4, name: 'Winter'}
]

export const VILLAINS: Villain[] = [
  {id: 1, name: 'LizardMan', superPower: "Shapeshifting", died: "true"},
  {id: 2, name: 'Godzilla', superPower: "Super Strength", died: "false"}
]
