import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { DashboardComponent } from './_components/dashboard/dashboard.component';
import { FormComponent } from './_components/form/form.component';
import { HeroDetailComponent } from './_components/hero-detail/hero-detail.component';
import { HeroesComponent } from './_components/heroes/heroes.component';
import { VillainsComponent } from './_components/villains/villains.component';

const routes: Routes = [
  // { path: '', redirectTo: '/dashboard', pathMatch: 'full' },
  { path: 'heroes', component: HeroesComponent },
  { path: 'villains', component: VillainsComponent },
  { path: 'dashboard', component: DashboardComponent },
  { path: 'detail/:heroType/:id', component: FormComponent }
  // { path: '**', redirectTo: '/dashboard' }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
