import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { HEROES, VILLAINS } from 'src/app/fake-db';
import { Hero } from 'src/app/_models/hero';
import { Villain } from 'src/app/_models/villain';
import { HeroService } from 'src/app/_services/hero.service';
import { VillainsService } from 'src/app/_services/villains.service';

@Component({
  selector: 'app-form',
  templateUrl: './form.component.html',
  styleUrls: ['./form.component.less']
})
export class FormComponent implements OnInit {
  currentHero?: Hero | Villain
  type: string = String(this.route.snapshot.paramMap.get('heroType'))

  constructor(
    private route: ActivatedRoute,
    private fb: FormBuilder,
    private _heroService: HeroService,
    private _villainService: VillainsService
  ) { }

  ngOnInit(): void {
    const id = Number(this.route.snapshot.paramMap.get('id'));

    if(this.type == "hero"){
      this._heroService.getHero(id)
        .subscribe(heroByID => this.currentHero = heroByID);
    }
    else{
      this._villainService.getVillain(id)
        .subscribe(villainByID => this.currentHero = villainByID);
    }

    if(this.currentHero){
      this.profileForm.setValue({
        name: this.currentHero.name,
        superPower:this.currentHero.superPower,
        died: this.currentHero.died
      })
    }
  }

  profileForm = this.fb.group({
    name: ['', Validators.required],
    superPower: ['', Validators.required],
    died: ['', Validators.required]
  });

  update(): void{

    if(this.currentHero && this.profileForm.value.name && this.profileForm.value.superPower && this.profileForm.value.died){

      this.currentHero.name = this.profileForm.value.name
      this.currentHero.superPower = this.profileForm.value.superPower
      this.currentHero.died = this.profileForm.value.died

      if(this.type == "hero"){
        let i = HEROES.findIndex(hero => hero.id == this.currentHero?.id)
        HEROES[i] = this.currentHero
      }
      else{
        let i = VILLAINS.findIndex(hero => hero.id == this.currentHero?.id)
        VILLAINS[i] = this.currentHero
      }
    }

  }

  delete(): void{
    if(this.currentHero){
      if(this.type == "hero"){
        let i = HEROES.findIndex(hero => hero.id == this.currentHero?.id)
        HEROES.splice(i, 1)
      }
      else{
        let i = VILLAINS.findIndex(hero => hero.id == this.currentHero?.id)
        VILLAINS.splice(i, 1)
      }
    }
  }

}
