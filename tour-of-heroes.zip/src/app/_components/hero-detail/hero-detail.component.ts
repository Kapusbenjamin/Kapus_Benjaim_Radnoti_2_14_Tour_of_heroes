import { Component, Input, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Villain } from 'src/app/_models/villain';
import { HeroService } from 'src/app/_services/hero.service';
import { VillainsService } from 'src/app/_services/villains.service';
import { Hero } from '../../_models/hero';

@Component({
  selector: 'app-hero-detail',
  templateUrl: './hero-detail.component.html',
  styleUrls: ['./hero-detail.component.less']
})
export class HeroDetailComponent implements OnInit {
  // ! -> force to not to be undefined
  hero?: Hero | undefined;
  villain?: Villain | undefined;


  constructor(
    private route: ActivatedRoute,
    private _heroService: HeroService,
    private _villainService: VillainsService
  ) { }

  ngOnInit(): void {
    if(this.route.snapshot.paramMap.get('heroType') == "hero"){
      this.getHeroByID();
    }
    else{
      this.getVillainByID();
    }
  }

  getHeroByID(): void {
    // url-ből kiveszi az "id" paramétert
    const id = Number(this.route.snapshot.paramMap.get('id'));
    this._heroService.getHero(id)
      .subscribe(heroByID => this.hero = heroByID);
  }

  getVillainByID(): void {
    const id = Number(this.route.snapshot.paramMap.get('id'));
    this._villainService.getVillain(id)
      .subscribe(villainByID => this.villain = villainByID);
  }

}
