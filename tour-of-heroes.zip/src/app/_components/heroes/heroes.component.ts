import { Component, OnInit } from '@angular/core';
import { Hero } from 'src/app/_models/hero';
import { HeroService } from 'src/app/_services/hero.service';
import { MessageService } from '../../_services/message.service';

@Component({
  selector: 'app-heroes',
  templateUrl: './heroes.component.html',
  styleUrls: ['./heroes.component.less']
})
export class HeroesComponent implements OnInit {
  heroesArray: Hero[] = [];
  // selectedHero?: Hero
  // selectedHeroDiv?: any

  constructor(
    private _heroService: HeroService
  ) { }

  ngOnInit(): void {
    // komponens betöltésekor lefut a metódus
    this.getHeroes();
  }

  // heroesArray betöltése a fake-db adataival
  getHeroes(): void {
    this._heroService.getHeroes().subscribe(result => this.heroesArray = result);
  }

  // onSelect(currentHero: Hero, e: any){
  //   console.log(currentHero)
  //   this.selectedHero = currentHero
  //   if(this.selectedHeroDiv){
  //     this.selectedHeroDiv.id = ""
  //   }
  //   const target = (e.currentTarget as HTMLElement).lastChild
  //   this.selectedHeroDiv = target
  //   this.selectedHeroDiv.id = "current"
  // }

}
