import { Component, OnInit } from '@angular/core';
import { Villain } from 'src/app/_models/villain';
import { MessageService } from 'src/app/_services/message.service';
import { VillainsService } from 'src/app/_services/villains.service';

@Component({
  selector: 'app-villains',
  templateUrl: './villains.component.html',
  styleUrls: ['./villains.component.less']
})
export class VillainsComponent implements OnInit {
  villainsArray: Villain[] = [];

  constructor(
    private _villainService: VillainsService
  ) { }

  ngOnInit(): void {
    this.getVillains()
  }

  getVillains(): void {
    this._villainService.getVillains().subscribe(result => this.villainsArray = result);
  }

}
