import { Component, OnInit } from '@angular/core';
import { Hero } from 'src/app/_models/hero';
import { HeroService } from 'src/app/_services/hero.service';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.less']
})
export class DashboardComponent implements OnInit {
  dashboardHeroes: Hero[] = [];

  constructor(private _heroService: HeroService) { }

  ngOnInit(): void {
    this.getDashboardHeroes();
  }

  getDashboardHeroes(): void {
    this._heroService.getHeroes()
      .subscribe(data => {
        this.dashboardHeroes = data.slice(0, 4);
        console.log(data);
      });
  }

}
