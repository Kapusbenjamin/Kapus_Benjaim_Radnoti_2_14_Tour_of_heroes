import { Component, OnInit } from '@angular/core';
import { Season } from 'src/app/_models/season';
import { SeasonService } from 'src/app/_services/season.service';

@Component({
  selector: 'app-season',
  templateUrl: './season.component.html',
  styleUrls: ['./season.component.less']
})
export class SeasonComponent implements OnInit {
  seasonsArray: Season[] = [];

  constructor(private _seasonService: SeasonService) { }

  ngOnInit(): void {
    this.getSeasons();
  }

  getSeasons(): void {
    this._seasonService.getSeasons().subscribe(result => this.seasonsArray = result);
  }

}
