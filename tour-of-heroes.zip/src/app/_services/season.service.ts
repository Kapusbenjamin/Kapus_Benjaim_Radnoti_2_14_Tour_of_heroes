import { Injectable } from '@angular/core';
import { Observable, of } from 'rxjs';
import { SEASONS } from '../fake-db';
import { Season } from '../_models/season';

@Injectable({
  providedIn: 'root'
})
export class SeasonService {

  constructor() { }

  getSeasons(): Observable<Season[]> {
    const seasons = of(SEASONS);
    return seasons;
  }
}
