import { Injectable } from '@angular/core';
import { Hero } from '../_models/hero';
import { HEROES } from '../fake-db';
import { Observable, of } from 'rxjs';
import { MessageService } from './message.service';

@Injectable({
  providedIn: 'root'
})
export class HeroService {

  constructor(private messageService: MessageService) { }

  getHeroes(): Observable<Hero[]> {
    const heroes = of(HEROES);
    this.messageService.add('HeroService: fetched heroes');
    return heroes;
  }

  // Melyik ID-jú herot szeretném lekérni
  getHero(id: number): Observable<Hero> {
    // Aktuális "i"-edik (element) ID-ja egyezik-e a paraméterben megadott id-val.
    // Létezik-e a tömbben a paraméterben megadott ID-jú elem
    const hero = HEROES.find(element => element.id === id)!;
    this.messageService.add(`HeroService: Selected hero id: ${hero.id}`);
    return of(hero);
  }
}
