import { Injectable } from '@angular/core';
import { Observable, of } from 'rxjs';
import { VILLAINS } from '../fake-db';
import { Villain } from '../_models/villain';
import { MessageService } from './message.service';

@Injectable({
  providedIn: 'root'
})
export class VillainsService {

  constructor(private messageService: MessageService) { }

  getVillains(): Observable<Villain[]> {
    const villains = of(VILLAINS);
    this.messageService.add('VillainService: fetched villains');
    return villains;
  }

  getVillain(id: number): Observable<Villain> {
    const villain = VILLAINS.find(element => element.id === id)!;
    this.messageService.add(`VillainService: Selected villain id: ${villain.id}`);
    return of(villain);
  }

}
