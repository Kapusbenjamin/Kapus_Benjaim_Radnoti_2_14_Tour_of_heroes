export interface Hero {
    id: number,
    name: string,
    superPower: string,
    died: string
    //optional property age?
    // age?: number

}
