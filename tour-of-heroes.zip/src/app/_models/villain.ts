export interface Villain {
  id: number,
  name: string,
  superPower: string,
  died: string
}
