export interface Season {
  id: number,
  name: string
}
